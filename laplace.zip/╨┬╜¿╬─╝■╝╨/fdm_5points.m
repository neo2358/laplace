
h=0.05;
n=2/h;
 f=@(x,y)(x^2-y^2);
bound=@(x,y) (x-0.5+y^2)^2+y^2;
m=2.5/h;

a=zeros((n+1)*(m+1),(n+1)*(m+1));  %系数矩阵
b=zeros((n+1)*(m+1),1);
for i = 1:(m+1)
    for j =1:(n+1)
    x=(i-1)*h-1;
    y=(j-1)*h-1;%坐标
    k=(j-1)*(m+1)+i;%a中序号
    if (bound(x-h,y)<1)&&(bound(x+h,y)<1)&&(bound(x,y-h)<1)&&(bound(x,y+h)<1)%内部点赋值
        a(k,k)=4;
        a(k,k-1)=-1;
        a(k,k+1)=-1;
        a(k,k-n-1)=-1;
        a(k,k+n+1)=-1;
        b(k)=0;
    elseif bound(x,y)<=1
        a(k,k)=1;
        b(k)=f(x,y);
    else 
        a(k,k)=1;
        b(k)=0;

    end
    end
end
v=a\b;
u=zeros(m+1,n+1);
e=zeros(m+1,n+1);
for i = 1:m+1
    for j =1:n+1
        if (v((j-1)*(n+1)+i)>0)
        u(i,j)=v((j-1)*(m+1)+i);
        e(i,j)=abs(u(i,j)-f(i*h-h-1,j*h-h-1));
        end
    end
end

 error=mean(mean(e));

