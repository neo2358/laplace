function   [h,l2error]=cal_function(func)

%边界点坐标
N = 300;
theta = (0 : N - 1)' * 2 * pi / N;

boundary_points = [cos(theta)+0.5*cos(2*theta) sin(theta)];

%内部点

r = ((30 : 500) / 501);
interior_point = [(cos(theta)+0.5*cos(2*theta)).* r    sin(theta) .* r ];
interior_point = reshape(interior_point, [], 2);
[num_interior,~]=size(interior_point);


%计算kernel
f = func(boundary_points(:, 1), boundary_points(:, 2));

gammadt = [cos(theta)  sin(theta)+sin(2*theta)];

kernel_matrix =  [boundary_points(:, 1)-boundary_points(:, 1)'   boundary_points(:, 2)-boundary_points(:, 2)'];
kernel_matrix = (kernel_matrix(:, 1 : N) .* gammadt(:, 1)' + kernel_matrix(:, N + 1 : end) .* gammadt(:, 2)') ./ (kernel_matrix(:, 1 : N) .^ 2 + kernel_matrix(:, N + 1 : end) .^ 2);
kernel_matrix(1 : N + 1 : end) = 1/2 * ((-cos(theta)-2*cos(2*theta)) .* gammadt(:, 1) + (-sin(theta)) .* gammadt(:, 2)) ./ (sum(gammadt .^ 2, 2));
kernel_matrix = 1/N * kernel_matrix - 0.5 * eye(N);

pj = kernel_matrix \ f;

%solve in the interior
iprec = 4;
nsource = N;
source = boundary_points';
ifcharge = 0;
charge = [];
ifdipole = 1;
dipstr = -1/N * pj;
dipvec = gammadt';
ifpot = 0;
ifgrad = 0;
ifhess = 0;
ntarget = num_interior;
targets = interior_point';
ifpottarg = 1;
ifgradtarg = 0;
ifhesstarg = 0;

[U] = rfmm2dpart(iprec,nsource,source,ifcharge,charge,ifdipole,dipstr,dipvec,ifpot,ifgrad,ifhess,ntarget,targets,ifpottarg,ifgradtarg,ifhesstarg);

u = U.pottarg'; 

% true_sol=func(interior_point(:, 1), interior_point(:, 2));
error=log10(abs(u - func(interior_point(:, 1), interior_point(:, 2)))+1e-15);
l2error=mean(abs(u - func(interior_point(:, 1), interior_point(:, 2))));
[X, Y] = meshgrid(linspace(-1, 1.5,1000),linspace(-1, 1,1000));
Z = griddata(interior_point(:,1), interior_point(:,2), error, X, Y,'linear');

isinterior=@(x,y)((x-0.5+y.^2).^2+y.^2);
Z(isinterior(X,Y)>1)=nan;


h=pcolor(X,Y,Z);
set(h, 'EdgeColor', 'none')
colorbar;
