PATH=/opt/gcc-4.4.2/bin:$PATH
export LD_LIBRARY_PATH=/opt/gcc-4.4.2/lib64
export OMP_STACK_SIZE=1024M

