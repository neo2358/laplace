PATH=/opt/octave-3.4.2/bin/:$PATH

PATH=/opt/gcc-4.4.4/bin/:$PATH
PATH=/opt/pkg-nyu-only/matlab/R2010b/bin/:$PATH

PATH=/Applications/MATLAB_R2011b.app/bin/:$PATH
